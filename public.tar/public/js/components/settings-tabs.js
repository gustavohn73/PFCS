export class SettingsTabsController {
    static inicializar()
    static configurarAbas()
    static carregarDadosConfiguracoes()
    static alternarAba(tabName)
}