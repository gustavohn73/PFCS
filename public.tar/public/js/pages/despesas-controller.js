export class DespesasController {
    static inicializar()
    static carregarDadosDespesas()
    static gerarGraficoComparacao()
    static carregarBreakdownCategorias()
}