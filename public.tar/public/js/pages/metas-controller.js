export class MetasController {
    static inicializar()
    static carregarMetas()
    static adicionarMeta()
    static editarMeta()
    static atualizarProgressoMeta()
}